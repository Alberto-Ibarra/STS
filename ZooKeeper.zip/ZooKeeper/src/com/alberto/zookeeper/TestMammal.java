package com.alberto.zookeeper;

public class TestMammal {

	public static void main(String[] args) {
		
//		 Mammal albert = new Mammal();
//		 albert.displayEnergy();
		 
		 Gorilla dylan = new Gorilla();
		 dylan.displayEnergy();
		 dylan.throwSomething();
		 dylan.throwSomething();
		 dylan.throwSomething();
		 dylan.eatBananas();
		 dylan.eatBananas();
		 dylan.displayEnergy();
		 dylan.climb();
		 dylan.displayEnergy();

	}

}
