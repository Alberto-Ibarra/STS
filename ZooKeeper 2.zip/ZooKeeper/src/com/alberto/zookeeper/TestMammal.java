package com.alberto.zookeeper;

public class TestMammal {

	public static void main(String[] args) {
		
//		 Mammal albert = new Mammal();
//		 albert.displayEnergy();
		 
//		 Gorilla dylan = new Gorilla();
//		 dylan.displayEnergy();
//		 dylan.throwSomething();
//		 dylan.throwSomething();
//		 dylan.throwSomething();
//		 dylan.eatBananas();
//		 dylan.eatBananas();
//		 dylan.displayEnergy();
//		 dylan.climb();
//		 dylan.displayEnergy();
		 
		 Bat daniel = new Bat();
		 daniel.displayEnergy();
		 daniel.attackTown();
		 daniel.attackTown();
		 daniel.attackTown();
		 daniel.displayEnergy();
		 daniel.eatHumans();
		 daniel.eatHumans();
		 daniel.displayEnergy();
		 daniel.fly();
		 daniel.fly();
		 daniel.displayEnergy();
	}

}
